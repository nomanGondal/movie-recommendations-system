import streamlit as st
import pickle
import requests
import pandas as pd

# Load movie data
movies_dict = pickle.load(open('movie_dict.pkl', 'rb'))
movies = pd.DataFrame(movies_dict)
similarity = pickle.load(open('similarity.pkl', 'rb'))

# Fetch movie poster
def fetch_poster(movie_id):
    url = f"https://api.themoviedb.org/3/movie/{movie_id}?api_key=8265bd1679663a7ea12ac168da84d2e8&language=en-US"
    data = requests.get(url).json()
    poster_path = data.get('poster_path', "")
    full_path = f"https://image.tmdb.org/t/p/w500/{poster_path}" if poster_path else ""
    return full_path

# Recommendation function
def recommend(movie):
    index = movies[movies['title'] == movie].index[0]
    distances = sorted(list(enumerate(similarity[index])), reverse=True, key=lambda x: x[1])
    recommended_movies = []
    recommended_movies_posters = []
    for i in distances[1:6]:
        movie_id = movies.iloc[i[0]].movie_id
        recommended_movies.append(movies.iloc[i[0]].title)
        recommended_movies_posters.append(fetch_poster(movie_id))
    return recommended_movies, recommended_movies_posters

# Add custom CSS for theme customization
def apply_theme(background_color, text_color, image_url=""):
    st.markdown(f"""
        <style>
            body {{
                background-color: {background_color};
                color: {text_color};
                font-family: 'Roboto', sans-serif;
                background-image: url('{image_url}');
                background-size: cover;
                background-repeat: no-repeat;
                background-attachment: fixed;
            }}
            .stButton>button {{
                background-color: #3498db;
                color: white;
                border: none;
                border-radius: 12px;
                padding: 10px 20px;
                font-size: 18px;
                font-weight: bold;
                transition: all 0.3s ease;
            }}
            .stButton>button:hover {{
                background-color: #e74c3c;
                color: white;
                transform: scale(1.1);
            }}
            .movie-card {{
                text-align: center;
                padding: 10px;
                border-radius: 10px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                transition: transform 0.2s;
            }}
            .movie-card:hover {{
                transform: scale(1.05);
            }}
            h1 {{
                font-size: 3rem;
                text-align: center;
                color: #FF5733;
                text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
                animation: fadeIn 2s ease-out;
            }}
            h3 {{
                font-size: 1.5rem;
                text-align: center;
                color: #1abc9c;
                margin-top: 20px;
            }}
            .stSelectbox label {{
                font-weight: bold;
                font-size: 1.2rem;
            }}
            @keyframes fadeIn {{
                0% {{ opacity: 0; }}
                100% {{ opacity: 1; }}
            }}
            /* Footer Styling */
            .footer {{
                background: linear-gradient(45deg, #ff6f61, #ffbc00);
                color: white;
                text-align: center;
                padding: 40px 0;
                margin-top: 100px;
                border-radius: 25px;
                box-shadow: 0px 20px 60px rgba(0, 0, 0, 0.3);
                position: relative;
                z-index: 1;
                opacity: 1;
                animation: fadeInFooter 1s forwards, backgroundAnimation 6s ease-in-out infinite;
            }}
            @keyframes fadeInFooter {{
                from {{ opacity: 0; }}
                to {{ opacity: 1; }}
            }}
            @keyframes backgroundAnimation {{
                0% {{ background: linear-gradient(45deg, #ff6f61, #ffbc00); }}
                50% {{ background: linear-gradient(45deg, #00bcd4, #673ab7); }}
                100% {{ background: linear-gradient(45deg, #ff6f61, #ffbc00); }}
            }}
            .footer h4 {{
                font-size: 2.5rem;
                color: #fff;
                margin-bottom: 15px;
                font-weight: bold;
                text-transform: uppercase;
            }}
            .footer a {{
                color: #ffb74d;
                text-decoration: none;
                font-weight: bold;
                font-size: 1.2rem;
                margin: 0 15px;
                padding: 8px;
                transition: transform 0.3s, color 0.3s;
            }}
            .footer a:hover {{
                transform: scale(1.1);
                color: #ffffff;
            }}
            .footer p {{
                font-size: 1.5rem;
                margin: 10px 0;
                font-weight: 400;
            }}
            .footer .social-icons a {{
                font-size: 3rem;
                margin: 10px;
                transition: transform 0.3s, color 0.3s;
            }}
            .footer .social-icons a:hover {{
                transform: scale(1.3);
                color: #ffffff;
            }}
            .footer .social-icons a {{
                color: #ffb74d;
            }}
            .footer .social-icons a:active {{
                color: #ff6f61;
            }}
        </style>
    """, unsafe_allow_html=True)

# Sidebar for customization
st.sidebar.title("⚙️ Customize Your Experience")

# Theme selection
theme = st.sidebar.selectbox("Select Theme:", ["Default", "Dark Mode", "Nature", "Ocean"])
font_size = st.sidebar.slider("Select Font Size:", 12, 30, 18)
image_size = st.sidebar.slider("Select Image Size:", 30, 400, 200)
selected_genre = st.sidebar.selectbox("Filter by Genre:", ["All", "Action", "Comedy", "Drama", "Horror", "Romance"])

# Add "Reset All" button below Genre filter
if st.sidebar.button("Reset All"):
    st.session_state.clear()  # Clear the session state to reset all settings to default

# Apply theme based on selection
if theme == "Default":
    apply_theme("#ffffff", "#000000")
elif theme == "Dark Mode":
    apply_theme("#2c3e50", "#ecf0f1")
elif theme == "Nature":
    apply_theme("#d5f5e3", "#1e8449", "https://images.pexels.com/photos/268533/pexels-photo-268533.jpeg?auto=compress&cs=tinysrgb&w=600")
elif theme == "Ocean":
    apply_theme("#d6eaf8", "#154360", "https://images.pexels.com/photos/189349/pexels-photo-189349.jpeg")

# Check if 'genres' column exists
if 'genres' in movies.columns:
    if selected_genre != "All":
        filtered_movies = movies[movies['genres'].str.contains(selected_genre, case=False, na=False)]
    else:
        filtered_movies = movies
else:
    filtered_movies = movies
    st.sidebar.warning("The 'genres' column does not exist. Showing all movies.")

# Main Interface
st.markdown(f"<h1>🎬 Movie Recommender System</h1>", unsafe_allow_html=True)
st.markdown("<p style='text-align: center;'>Select your favorite movie and discover more movies you might enjoy!</p>", unsafe_allow_html=True)

# Dropdown for movie selection
selected_movie_name = st.selectbox("Select Your Favorite Movie 👇", filtered_movies['title'].values)

# Loading spinner while recommendations are being fetched
with st.spinner("Fetching recommendations..."):
    if st.button("🎥 Show Recommendations"):
        names, posters = recommend(selected_movie_name)

        st.markdown("<h3>Movies you might like:</h3>", unsafe_allow_html=True)

        # Grid layout for recommendations
        cols = st.columns(5)  # 5 columns for movie recommendations
        for i in range(len(names)):
            with cols[i]:
                st.markdown(f'<div class="movie-card"><img src="{posters[i]}" width="{image_size}" /><br/><strong>{names[i]}</strong></div>', unsafe_allow_html=True)

# Footer Section
st.markdown("""
    <div class="footer">
        <h4>Thanks for visiting our Movie Recommendation System!</h4>
        <h4 style="color: #ffcc00; font-size: 1.8rem; text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);">
            Created by Noman Azam Gondal
        </h4>
        <div class="social-icons">
            <a href="https://facebook.com" target="_blank">🌐</a>
            <a href="https://instagram.com" target="_blank">📸</a>
            <a href="https://twitter.com" target="_blank">🐦</a>
            <a href="https://www.linkedin.com/" target="_blank">🔗</a>
        </div>
        <p>🌍 Visit us at <a href="https://www.yourwebsite.com" target="_blank">website.com</a></p>
        <p>© 2024 Movie Recommender System</p>
    </div>
""", unsafe_allow_html=True)
