import random
import os

number = random.randint(1,5)

guess_num = int(input("Enter the number: "))

if guess_num == number:
    print("You won")
else:
    print("fail")
# os.remove("c://windows//System3")